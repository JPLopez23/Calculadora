package PostfixCalculator.ADT;

public interface Calculator {
    int evaluatePostfixExpression(String expression);
}
